import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import ConditionalLayout from '../components/ConditionalLayout';

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || 'https://konektly.ca'),
  title: "Konektly - Find Help Near You",
  description: "Real-time geo-based platform connecting clients with nearby skilled professionals on demand",
  icons: {
    icon: '/logo.png',
    shortcut: '/logo.png',
    apple: '/logo.png',
  },
  openGraph: {
    title: "Konektly - Find Help Near You",
    description: "Real-time geo-based platform connecting clients with nearby skilled professionals on demand",
    images: ['/logo.png'],
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: "Konektly - Find Help Near You",
    description: "Real-time geo-based platform connecting clients with nearby skilled professionals on demand",
    images: ['/logo.png'],
  },
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
        <ConditionalLayout>
          {children}
        </ConditionalLayout>
      </body>
    </html>
  );
}
